<?php

//connect to SQL
$servername = "localhost";
$username = "ludgi";
$pass = "ecgr4090";
$db_name = "49ersense";


$conn = mysqli_connect($servername,$username,$pass,$db_name);

//
if($conn){
  echo "Connection Sucessful!";
}
else {
    "Connection Error: " . mysqli_connect_error();
}



?>
