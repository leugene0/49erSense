<?php
require "connect.php";

$user_name = $_POST["user_name"];
$user_pass = $_POST["pass_word"];

$mysql_qry = "select * from login where username like '$user_name' and password like '$user_pass';";
$result = mysqli_query($conn, $mysql_qry);
if(mysqli_num_rows($result)>0){
echo "  Login Sucessful!!!!";
}
else {
  echo "Login not Sucessful";
}
 ?>
