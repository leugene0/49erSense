<?php
require "connect.php";

$user_name = $_POST["user_name"];
$user_pass = $_POST["pass_word"];
$name = $_POST["user"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$acctType = $_POST["account"];

$mysql_qry = "INSERT INTO login(accountType,username,password,Name,Email,Phone) VALUES('$acctType', '$user_name', '$user_pass', '$name', '$email', '$phone')";
$result = mysqli_query($conn, $mysql_qry);
if($result){
echo "new user added";
}
else {
  echo "Login not Sucessful";
}
 ?>
