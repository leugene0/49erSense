package com.example.a49ersense;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;


public class MainActivity extends AppCompatActivity {
    loadData asyncTask=new loadData();
    ProgressBar progressBar;
    EditText usern, pass;
    Global userid, acctType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final Button loginButt = (Button) findViewById(R.id.login);
        final Button create = (Button)findViewById(R .id.createacctButton);
        userid = (Global) getApplicationContext();
        acctType = (Global) getApplicationContext();


        progressBar = (ProgressBar) findViewById(R.id.progressBar1);
        //progressBar.setVisibility(View.INVISIBLE);
        usern =(EditText)findViewById(R.id.username_editText);
        pass =(EditText)findViewById(R.id.password_editText);
        int place = 1;
       // MyTask myTask = new MyTask();
        //myTask.execute();



        loginButt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String u = usern.getText().toString();
                String p = pass.getText().toString();
                asyncTask.execute(u,p);


            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Intent1 = new Intent(MainActivity.this, CreateAccount.class);
                    startActivity(Intent1);


            }
        });


    }

    private class loadData extends AsyncTask<String, Void, String> {
        String result = "";


        @Override
        protected void onPreExecute(){
            super.onPreExecute();
            progressBar = new ProgressBar(MainActivity.this);
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... args) {
           String login_url = "http://10.220.1.60/IoT/login.php";
            try {


                String userName = args[0];
                String passWord = args[1];

                URL url = new URL(login_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("user_name", "UTF-8")+ "=" + URLEncoder.encode(userName, "UTF-8") + "&"
                        + URLEncoder.encode("pass_word", "UTF-8")+ "=" + URLEncoder.encode(passWord, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

               // get result data
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));


                String line ="";
                while((line = bufferedReader.readLine())!=null){
                    result+= line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
            }catch (IOException e){
                throw new RuntimeException(e);
            }




            return result;

        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
          //  progressBar.setVisibility(View.INVISIBLE);
                //Intent Supplier = new Intent(MainActivity.this, )
                Intent consumer = new Intent(MainActivity.this, HomeScreen.class);
                Intent supplier = new Intent(MainActivity.this,UserChoice.class);
                Intent gridControl = new Intent(MainActivity.this, GridControllerMenu.class);
                // pull uuid and assign to global variable

                int uuid = userid.getUuid();
                String acct = acctType.getAcct();
                acct ="1";

                if (acct == "0"){
                Toast.makeText(getApplicationContext(), "Log in Successful!", Toast.LENGTH_SHORT).show();
                startActivity(consumer);
                }
                if (acct =="1") {
                    Toast.makeText(getApplicationContext(), "Log in Successful!", Toast.LENGTH_SHORT).show();
                    startActivity(supplier);
                }
                if(acct=="2"){
                    Toast.makeText(getApplicationContext(), "Log in Successful!", Toast.LENGTH_SHORT).show();
                    startActivity(gridControl);
                }

            else
                Toast.makeText(getApplicationContext(), "Log in Failed, Try again", Toast.LENGTH_LONG).show();

        }
    }
}
