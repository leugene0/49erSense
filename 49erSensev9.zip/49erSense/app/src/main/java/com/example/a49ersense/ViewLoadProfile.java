package com.example.a49ersense;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Arrays;

public class ViewLoadProfile extends AppCompatActivity
{

    String[] loadProf = {""}; // Displaying past rev
    TextView dispText; // for displaying stuff from data base graphically


    private class loadData extends AsyncTask<Void, Void, String[]> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected String[] doInBackground(Void... args) {
            // pull load profile data

            String clientname, powerConsumed, PowerGenerated;

            //store in load prof

            return loadProf;
        }

        @Override
        protected void onPostExecute(String[] loadProf) {
            super.onPostExecute(loadProf);

            // print nicely
            dispText.setText(Arrays.toString(loadProf));

        }
    }


    public void goToUsersSupplied(View view)
    {

        loadData getFromDB = new loadData(); // async initialization
        getFromDB.execute();

    }

    public void goToBack(View view)
    {
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_load_profile);

        dispText = findViewById(R.id.textView13);
    }
}
