
package com.example.a49ersense;

import android.app.Application;

public class Global extends Application {
    private int uuid;
    private String acct;

    public int getUuid() {
        return uuid;
    }

    public void setUuid(int uuid) {
        this.uuid = uuid;
    }

    public String getAcct() {
        return acct;
    }

    public void setAcct(String acct) {
        this.acct = acct;
    }




}

