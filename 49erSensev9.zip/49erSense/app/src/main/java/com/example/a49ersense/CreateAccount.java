
package com.example.a49ersense;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.RadioGroup;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;


public class CreateAccount extends AppCompatActivity {
    Button submit;
    EditText user, pass, name, email, phone;
    Integer idx;
    RadioGroup radioButtongroup;
    ProgressBar progressBar;
    loadData asyncTask=new loadData();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        submit =(Button)findViewById(R.id.submitButton);
        user =(EditText)findViewById(R.id.usernameNew);
        pass =(EditText)findViewById(R.id.passwordNew);
        name =(EditText)findViewById(R.id.nameNew);
        email =(EditText)findViewById(R.id.emailNew);
        phone =(EditText)findViewById(R.id.phoneNew);
        radioButtongroup =(RadioGroup)findViewById(R.id.radioGroup);

        //radioButton index
       

        progressBar = (ProgressBar) findViewById(R.id.progressBar1);
        progressBar.setVisibility(View.INVISIBLE);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int radioButtonID = radioButtongroup.getCheckedRadioButtonId();
                View radioButton = radioButtongroup.findViewById(radioButtonID);
                idx = radioButtongroup.indexOfChild(radioButton);
                String u = user.getText().toString();
                String p = pass.getText().toString();
                String n = name.getText().toString();
                String e = email.getText().toString();
                String ph = phone.getText().toString();
                String index = idx.toString();

                asyncTask.execute(u,p,n,e,ph,index);
            }
        });
    }
    private class loadData extends AsyncTask<String, String, String>{
        String result = "";
        @Override
        protected void onPreExecute(){
            super.onPreExecute();
            progressBar = new ProgressBar(CreateAccount.this);
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... args) {
            String login_url = "http://10.220.1.60/IoT/register.php";
            try {


                String userName = args[0];
                String passWord = args[1];
                String name = args[2];
                String email = args[3];
                String phone = args[4];
                String acctType = args[5];

                URL url = new URL(login_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("user_name", "UTF-8")+ "=" + URLEncoder.encode(userName, "UTF-8") + "&"
                        + URLEncoder.encode("pass_word", "UTF-8")+ "=" + URLEncoder.encode(passWord, "UTF-8")+ "&"
                        + URLEncoder.encode("user", "UTF-8")+ "=" + URLEncoder.encode(name, "UTF-8")+ "&"
                        + URLEncoder.encode("email", "UTF-8")+ "=" + URLEncoder.encode(email, "UTF-8")+ "&"
                        + URLEncoder.encode("phone", "UTF-8")+ "=" + URLEncoder.encode(phone, "UTF-8")+ "&"
                        + URLEncoder.encode("account", "UTF-8")+ "=" + URLEncoder.encode(acctType, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                // get result data
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));


                String line ="";
                while((line = bufferedReader.readLine())!=null){
                    result+= line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
            }catch (IOException e){
                throw new RuntimeException(e);
            }

            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            progressBar.setVisibility(View.INVISIBLE);

            if(result != "") {
                Toast.makeText(getApplicationContext(), "Account Created Successfully!", Toast.LENGTH_SHORT).show();
                finish();
            }
            else
                Toast.makeText(getApplicationContext(), "Something went wrong", Toast.LENGTH_SHORT).show();


        }
    }

}

