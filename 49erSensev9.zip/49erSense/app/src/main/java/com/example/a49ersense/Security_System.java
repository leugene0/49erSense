package com.example.a49ersense;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;

public class Security_System extends AppCompatActivity {
    Global userid;
    TextView display;
    Boolean securityState;
    Switch secure;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarms);

        loadData show =new loadData();
        secure = (Switch)findViewById(R.id.security__switch);
        userid = (Global) getApplicationContext();
        Button apply = (Button)findViewById(R.id.apply_button2);
        display =findViewById(R.id.secure_textView);

        show.execute();

        apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                securityState = secure.isChecked();
                storeData asyncTask=new storeData();
                asyncTask.execute(securityState);
                //Toast.makeText(getApplicationContext(),"Changes Saved Successfully!", Toast.LENGTH_SHORT).show();
            }
        });

    }
    private class storeData extends AsyncTask<Boolean, String, Void> {
        @Override
        protected void onPreExecute(){

        }

        @Override
        protected Void doInBackground(Boolean... args) {
            //updateDevice for 3 locks (front, back, garage)

            //TODO: NEEDED VARIABLES
            //UUID - returned to you on login, keep it available always
            int id = userid.getUuid();

            Boolean isSecure = args[0];

            int Security = isSecure ? 1 : 0;

            // Store status in Database

            //TODO: Check for success or error
            //if successful, success1 AND success2 AND success3 will all equal 1. Failed = -1 on any of these three.

            return null;
        }

        @Override
        protected void onPostExecute(Void g) {
            //super.onPostExecute(null);
            loadData show2 = new loadData();
            show2.execute();
            Toast.makeText(getApplicationContext(),"Changes saved Successfully!", Toast.LENGTH_SHORT).show();


        }
    }

    private class loadData extends AsyncTask<Void, Void, String[]> {

        @Override
        protected void onPreExecute(){
            super.onPreExecute();

        }

        @Override
        protected String[] doInBackground(Void... args) {
            // need to make connections and pull devices from database
            String [] isArmed = {"Device 1", "Device 2"};
            // set devices from database to device array
            return isArmed;
        }

        @Override
        protected void onPostExecute(String[] isArmed) {
            //super.onPostExecute(devices);
            display.setText(Arrays.toString(isArmed));


        }
    }

}
